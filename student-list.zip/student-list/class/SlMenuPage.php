<?php

class SlMenuPage{

    function __construct()
    {
        add_action( 'admin_menu', array( $this, 'addMyAdminMenu' ) );
    }


    
    /**
     * Add Admin Menu Page
     */

     public function addMyAdminMenu() {
         
        add_menu_page(
           'My Page Title',
           'My Page',
           'read',
           'my-menu-page-slug',
           array(
               $this,
               'myAdminPage'
           ),
           'to/icon/file.svg',
           '2'
       );
   }

   public function myAdminPage() {
        // Echo the html here...
   }


}








