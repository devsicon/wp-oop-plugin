<?php

 if(!defined('ABSPATH')){
    exit();
 }


/*
 * Plugin Name:       Student List
 * Plugin URI:        https://codeindeed.com/plugins/student-list/
 * Description:       Handle the basics with this plugin.
 * Version:           1.1.08
 * Requires at least: 5.6
 * Requires PHP:      7.2
 * Author:            Md. Mahmudul Hasan
 * Author URI:        https://codeindeed.com/mahmud/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://codeindeed.com/plugins/student-list/
 * Text Domain:       studentlist
 * Domain Path:       /languages
 */


    /**
     * @package Student List
     * @since 1.0.0
     * @version 1.0.0
     */

 class StudentList {
    
    public $version = '';
    public $text_domain = '';
    protected static $_instance = null;


    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }


    function __construct()
    {
        $this->student_list_plugin_data();
        $this->student_list_define_constant();
        

        // spl_autoload_register( array( $this, 'autoload' ) );

        add_action( 'plugins_loaded', array( $this, 'student_list_load_plugin_textdomain' ));
        add_action( 'admin_enqueue_scripts', array( $this, 'student_list_admin_assets_enqueue' ) );
    }

    /**
     * Plugin data load, (Version & Textdomain)
     */

    public function student_list_plugin_data(){
        if( ! function_exists('get_plugin_data') ){
            require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
         }

        $plugin_data = get_plugin_data( __FILE__ );

        $this->version = $plugin_data['Version'];
        $this->text_domain = $plugin_data['TextDomain'];

    }

    /**
     * Constant Define
     */
    public function student_list_define_constant(){
        define('STUDENT_LIST_VERSION', $this->version);
        define('STUDENT_LIST_DIR_URL', plugin_dir_url(__FILE__)); // Return value = http://localhost/plugindev/wp-content/plugins/first-plugin/
        define('STUDENT_LIST_DIR_PATH', plugin_dir_path(__FILE__)); // Return value = F:\server\htdocs\plugindev\wp-content\plugins\first-plugin/
        define('STUDENT_LIST_BASENAME', plugin_basename(__FILE__)); // Return value = first-plugin/first-plugin.php
        define('STUDENT_LIST_ASSETS_URL', STUDENT_LIST_DIR_URL . 'assets/');
        define('STUDENT_LIST_INC_DIR_PATH', STUDENT_LIST_DIR_PATH . 'inc/');
    }


    /**
     * Class Autoload
     */
    // function autoload( $class ) { 
    //     $filename = dirname( __FILE__ ) . '/class/' . $class . '.php';
    //     if ( file_exists( $filename ) ) {
    //         require_once $filename;
    //     }
    // }

    public function required_file_load(){
        include STUDENT_LIST_DIR_PATH . 'class/SlMenuPage.php';
    }

    /**
     * Load plugin textdomain
     */
    function student_list_load_plugin_textdomain() {
        load_plugin_textdomain( $this->text_domain, false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
    }

    

    /**
     * Plugin Assets Enqueue
     */
    public function student_list_admin_assets_enqueue(){


        $screen = get_current_screen();

        // Check screen base and page
        if ( 'options-general' === $screen->base && $_GET['page'] ==='uwc' )
        {
            wp_enqueue_style('sl-bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css', '', STUDENT_LIST_VERSION, 'all');
            

        } 


    }
    

 }


    function StudentListInit() {
        return StudentList::instance();
    }

    //Class  instance.
    $StudentList = StudentListInit();


